package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.io.InputStream;
import java.io.FileNotFoundException;


public class EmployeeDatabase {
    public Connection connection;
    private final PreparedStatement insertEmployeeStatement1;
    private final PreparedStatement insertEmployeeStatement2;
    private final PreparedStatement insertEmployeeStatement3;
    private final PreparedStatement updateEmployeeStatement1;
    private final PreparedStatement updateEmployeeStatement2;
    private final PreparedStatement updateEmployeeStatement3;
    private final PreparedStatement deleteEmployeeStatement1;
    private final PreparedStatement deleteEmployeeStatement2;
    private final PreparedStatement deleteEmployeeStatement3;
    private PreparedStatement searchEmployeeStatement1;

    private PreparedStatement searchEmployeeStatement2;
    private PreparedStatement searchEmployeeStatement3;

    Logger logger = LogManager.getLogger();
   Properties properties = new Properties();



    public EmployeeDatabase() throws SQLException {
        //try (FileInputStream fileInputStream = new FileInputStream("C://Users//sreehitha.c//eclipse-workspace//NewTask4//src//main//resources//config.properties")) { using path
        try (InputStream inputStream = Main.class.getClassLoader().getResourceAsStream("config.properties")) {
            properties.load(inputStream);     //properties.load(fileInputStream);
            String databaseUrl = properties.getProperty("database.url");
            String databaseUsername = properties.getProperty("database.username");
            String databasePassword = properties.getProperty("database.password");
            connection = DriverManager.getConnection(databaseUrl, databaseUsername, databasePassword);

            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
           // connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee", "root", "Sree@1234567");
            insertEmployeeStatement1 = connection.prepareStatement("INSERT INTO PermanentEmployee(id,name,salary,bonus) VALUES(?,?,?,?)");
            insertEmployeeStatement2 = connection.prepareStatement("INSERT INTO PartTimeEmployee(id,name,salary,hoursWorked) VALUES(?,?,?,?)");
            insertEmployeeStatement3 = connection.prepareStatement("INSERT INTO ContractEmploee(id,name,salary,contractPeriod) VALUES(?,?,?,?)");
            updateEmployeeStatement1 = connection.prepareStatement("UPDATE PermanentEmployee SET name = ?,salary = ?,bonus = ? WHERE id = ?");
            updateEmployeeStatement2 = connection.prepareStatement("UPDATE PartTimeEmployee SET name = ?,salary = ?,hoursWorked = ? WHERE id = ?");
            updateEmployeeStatement3 = connection.prepareStatement("UPDATE ContractEmploee SET name = ?,salary = ?,contractPeriod = ? WHERE id = ?");
            deleteEmployeeStatement1 = connection.prepareStatement("DELETE FROM PermanentEmployee WHERE id = ?");
            deleteEmployeeStatement2 = connection.prepareStatement("DELETE FROM PartTimeEmployee WHERE id = ?");
            deleteEmployeeStatement3 = connection.prepareStatement("DELETE FROM ContractEmploee WHERE id = ?");
            searchEmployeeStatement1 = connection.prepareStatement("SELECT * FROM PermanentEmployee WHERE id = ?");
            searchEmployeeStatement2 = connection.prepareStatement("SELECT * FROM PartTimeEmployee WHERE id = ?");
            searchEmployeeStatement3 = connection.prepareStatement("SELECT * FROM ContractEmployee WHERE id = ?");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public  void addEmployee(PermanentEmployee permanentEmployee) throws SQLException {
        try {
            insertEmployeeStatement1.setInt(1, permanentEmployee.getId());
            insertEmployeeStatement1.setString(2, permanentEmployee.getName());
            insertEmployeeStatement1.setInt(3, permanentEmployee.getSalary());
            insertEmployeeStatement1.setInt(4, permanentEmployee.getBonus());
            insertEmployeeStatement1.executeUpdate();
            logger.info("PERMANENT EMPLOYEE ADDED");
        } catch (Exception e) {
            logger.warn("Duplicate Found");
        }
        finally {
            insertEmployeeStatement1.close();
            connection.close();
        }
    }
    public void addEmployee(PartTimeEmployee partTimeEmployee) throws SQLException
    {
        try {
            insertEmployeeStatement2.setInt(1, partTimeEmployee.getId());
            insertEmployeeStatement2.setString(2, partTimeEmployee.getName());
            insertEmployeeStatement2.setInt(3, partTimeEmployee.getSalary());
            insertEmployeeStatement2.setInt(4, partTimeEmployee.getHoursWorked());
            insertEmployeeStatement2.executeUpdate();
            logger.info("PART TIME EMPLOYEE ADDED");
        }
        catch (Exception e){
            logger.warn("Duplicate Found");
        }
        finally {
            insertEmployeeStatement2.close();
            connection.close();
        }

    }
    public void addEmployee(ContractEmployee contractEmploee) throws SQLException
    {
        try
        {
        insertEmployeeStatement3.setInt(1,contractEmploee.getId());
        insertEmployeeStatement3.setString(2,contractEmploee.getName());
        insertEmployeeStatement3.setInt(3,contractEmploee.getSalary());
        insertEmployeeStatement3.setInt(4,contractEmploee.getContractperiod());
        insertEmployeeStatement3.executeUpdate();
        logger.info("CONTRACT EMPLOYEE ADDED");
    }
        catch (Exception e){
            logger.warn("Duplicate Found");
        }
        finally {
            insertEmployeeStatement3.close();
            connection.close();
        }
        }

    public void updateEmployee(PermanentEmployee permanentEmployee) throws SQLException
    {
        try{
        updateEmployeeStatement1.setString(1, permanentEmployee.getName());
        updateEmployeeStatement1.setInt(2, permanentEmployee.getSalary());
        updateEmployeeStatement1.setInt(3, permanentEmployee.getBonus());
        updateEmployeeStatement1.setInt(4, permanentEmployee.getId());
        updateEmployeeStatement1.executeUpdate();
        logger.info("PERMANENT EMPLOYEE DETAILS UPDATED");
    }catch (Exception e){
            logger.warn("Employee not Found");
        }
        finally {
            updateEmployeeStatement1.close();
            connection.close();
        }
        }
    public void updateEmployee(PartTimeEmployee partTimeEmployee) throws SQLException
    {
        try
        {
        updateEmployeeStatement2.setString(1, partTimeEmployee.getName());
        updateEmployeeStatement2.setInt(2, partTimeEmployee.getSalary());
        updateEmployeeStatement2.setInt(3, partTimeEmployee.getHoursWorked());
        updateEmployeeStatement2.setInt(4, partTimeEmployee.getId());
        logger.info("PART TIME EMPLOYEE DETAILS UPDATED");
    }
        catch (Exception e){
            logger.warn("Employee not Found");
        }finally {
            updateEmployeeStatement2.close();
            connection.close();
        }
        }
    public void updateEmployee(ContractEmployee contractEmploee) throws SQLException
    {
        try{
        updateEmployeeStatement3.setString(1, contractEmploee.getName());
        updateEmployeeStatement3.setInt(2, contractEmploee.getSalary());
        updateEmployeeStatement3.setInt(3, contractEmploee.getContractperiod());
        updateEmployeeStatement3.setInt(4, contractEmploee.getId());
        logger.info("CONTRACT EMPLOYEE DETAILS UPDATED");
    } catch (Exception e){
            logger.warn("Employee not Found");
        }finally {
            updateEmployeeStatement3.close();
            connection.close();
        }
        }

    public void deleteEmployee1(int id) throws SQLException {
        try {
            deleteEmployeeStatement1.setInt(1, id);
            int result = deleteEmployeeStatement1.executeUpdate();
            if (result > 0) {
                logger.info("DETAILS DELETED");
            } else {
                logger.warn("Employee not Found");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
            finally
            {
                deleteEmployeeStatement1.close();
                connection.close();
            }
        }
    public void deleteEmployee2(int id) throws SQLException
    {
        try {
            deleteEmployeeStatement2.setInt(1, id);
            int result = deleteEmployeeStatement2.executeUpdate();
            if (result > 0) {
                logger.info("DETAILS DELETED");
            } else {
                logger.warn("Employee not found");
            }
        }
        finally {
            deleteEmployeeStatement2.close();
            connection.close();
        }
        }
    public void deleteEmployee3(int id) throws SQLException
    {
        try {
            deleteEmployeeStatement3.setInt(1, id);
            int result = deleteEmployeeStatement3.executeUpdate();
            if (result > 0) {
                logger.info("DETAILS DELETED");
            } else {
                logger.warn("Employee not Found");
            }
        }finally {
            deleteEmployeeStatement3.close();
            connection.close();
        }
        }
        public void permanentJson() throws SQLException{
        ResultSet resultSet = null;
        try
        {
        String SELECT_EMPLOYEES_QUERY = "SELECT id, name, salary, bonus FROM PermanentEmployee";
        Statement statement = connection.createStatement();
        resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
        JSONArray jsonArray = new JSONArray();
        while (resultSet.next()) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", resultSet.getInt("id"));
            jsonObject.put("name", resultSet.getString("name"));
            jsonObject.put("salary", resultSet.getInt("salary"));
            jsonObject.put("bonus",resultSet.getInt("bonus"));
            jsonArray.put(jsonObject);
        }
        System.out.println(jsonArray);
    }
        finally {
            if (resultSet!=null)
            {
                resultSet.close();
            }
            connection.close();
        }
        }

    public void partTimeJson() throws SQLException
    {
        //try (FileInputStream fileInputStream = new FileInputStream("C://Users//sreehitha.c//eclipse-workspace//NewTask4//src//main//resources//config.properties")) {
        try (InputStream inputStream = Main.class.getClassLoader().getResourceAsStream("config.properties")) {
            properties.load(inputStream);//  properties.load(fileInputStream);
            String databaseUrl = properties.getProperty("database.url");
            String databaseUsername = properties.getProperty("database.username");
            String databasePassword = properties.getProperty("database.password");
            connection = DriverManager.getConnection(databaseUrl, databaseUsername, databasePassword);
        }catch (IOException e){
            throw new RuntimeException();
        }

            // connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee", "root","Sree@1234567");
        ResultSet resultSet = null;
        try
        {
        String SELECT_EMPLOYEES_QUERY = "SELECT id, name, salary, hoursWorked  FROM PartTimeEmployee";
        Statement statement = connection.createStatement();
        resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
        JSONArray jsonArray = new JSONArray();
        while (resultSet.next()) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", resultSet.getInt("id"));
            jsonObject.put("name", resultSet.getString("name"));
            jsonObject.put("salary", resultSet.getInt("salary"));
            jsonObject.put("hoursWorked",resultSet.getInt("hoursWorked"));
            jsonArray.put(jsonObject);
        }
        System.out.println(jsonArray);
    }finally {
            if (resultSet!=null)
            {
                resultSet.close();
            }
        connection.close();
        }
        }
    public void contractJson() throws SQLException {
       // try (FileInputStream fileInputStream = new FileInputStream("C://Users//sreehitha.c//eclipse-workspace//NewTask4//src//main//resources//config.properties")) {
        try (InputStream inputStream = Main.class.getClassLoader().getResourceAsStream("config.properties")) {
            properties.load(inputStream);   //properties.load(fileInputStream);
            String databaseUrl = properties.getProperty("database.url");
            String databaseUsername = properties.getProperty("database.username");
            String databasePassword = properties.getProperty("database.password");
            connection = DriverManager.getConnection(databaseUrl, databaseUsername, databasePassword);
        }catch (IOException e){
            throw new RuntimeException();
        }

      //  connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employee", "root","Sree@1234567");
        ResultSet resultSet = null;
        try {
            String SELECT_EMPLOYEES_QUERY = "SELECT id, name, salary, contractPeriod  FROM ContractEmploee";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(SELECT_EMPLOYEES_QUERY);
            JSONArray jsonArray = new JSONArray();
            while (resultSet.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", resultSet.getInt("id"));
                jsonObject.put("name", resultSet.getString("name"));
                jsonObject.put("salary", resultSet.getInt("salary"));
                jsonObject.put("contractPeriod", resultSet.getInt("contractPeriod"));
                jsonArray.put(jsonObject);
            }
            System.out.println(jsonArray);
        }finally {
            if (resultSet!=null){
                resultSet.close();
            }
            connection.close();
        }
    }

public  String searchRecord(int id,int empno) throws SQLException, ClassNotFoundException
{

    String jsonData = "1";

    //try (FileInputStream fileInputStream = new FileInputStream("C://Users//sreehitha.c//eclipse-workspace//NewTask4//src//main//resources//config.properties")) {
    try (InputStream inputStream = Main.class.getClassLoader().getResourceAsStream("config.properties")) {
        properties.load(inputStream);// properties.load(fileInputStream);
        String databaseUrl = properties.getProperty("database.url");
        String databaseUsername = properties.getProperty("database.username");
        String databasePassword = properties.getProperty("database.password");
        connection = DriverManager.getConnection(databaseUrl, databaseUsername, databasePassword);
    }catch (IOException e){
        throw new RuntimeException();
    }

   // connection =  DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "Sree@1234567");
    ResultSet resultSet1 = null;
    ResultSet resultSet2 = null;
    ResultSet resultSet3 = null;
    if(empno==1)
    {
        searchEmployeeStatement1 = connection.prepareStatement("SELECT id, name,salary, bonus from PermanentEmployee WHERE id = ?");
        searchEmployeeStatement1.setInt(1, id);
        resultSet1 = searchEmployeeStatement1.executeQuery();
        JSONArray jsonArray = new JSONArray();
        while (resultSet1.next())
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("empId", resultSet1.getInt("id"));
            jsonObject.put("name", resultSet1.getString("name"));
            jsonObject.put("salary", resultSet1.getInt("salary"));
            jsonObject.put("bonus", resultSet1.getInt("bonus"));
            jsonArray.put(jsonObject);
            jsonData = jsonArray.toString();
        }
    }
    else if(empno==2)
    {
        searchEmployeeStatement2= connection.prepareStatement("SELECT id, name,salary, hoursWorked from PartTimeEmployee WHERE id = ?");
        searchEmployeeStatement2.setInt(1, id);
        resultSet2 = searchEmployeeStatement2.executeQuery();
        JSONArray jsonArray = new JSONArray();
        while (resultSet2.next())
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("empId", resultSet2.getInt("id"));
            jsonObject.put("name", resultSet2.getString("name"));
            jsonObject.put("salary", resultSet2.getInt("salary"));
            jsonObject.put("hoursWorked", resultSet2.getInt("hoursWorked"));
            jsonArray.put(jsonObject);
            jsonData = jsonArray.toString();
        }
    }
    else if(empno==3)
    {
        searchEmployeeStatement3 = connection.prepareStatement("SELECT id, name,salary,contractPeriod from ContractEmploee WHERE id = ?");
        searchEmployeeStatement3.setInt(1, id);
        resultSet3 = searchEmployeeStatement3.executeQuery();
        JSONArray jsonArray = new JSONArray();
        while (resultSet3.next())
        {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("empId", resultSet3.getInt("id"));
            jsonObject.put("name", resultSet3.getString("name"));
            jsonObject.put("salary", resultSet3.getInt("salary"));
            jsonObject.put("contractPeriod", resultSet3.getInt("contractPeriod"));
            jsonArray.put(jsonObject);
            jsonData = jsonArray.toString();
        }
    }

        return jsonData;
}
}


